# PF2e-BKNS-Effects
A foundryVTT module for the PF2e system that enables users to quickly create macros which apply effects/conditions automatically when using a spell or ability
